import { promises as fs } from 'fs';
import { decode } from 'html-entities';
// 
import data_map from './data_Map.json' assert { type: 'json' };
import data_hsMap from './data_hsMap.json' assert { type: 'json' };
import data_hsMap_lkc from './data_hsMap_lkc.json' assert { type: 'json' };
import data_mapId_hsUrl_Manual from './data_mapId_hsUrl_Manual.json' assert { type: 'json' };

// console.log(data_map)
// console.log(data_hsMap)

const mapNameToUrlObj = {}  // {str : url}
const combinedArr = [...data_hsMap, ...data_hsMap_lkc]
combinedArr.forEach(({ URL, mapName }) => {
    // mapNameToUrlObj[mapName.toLowerCase()] = URL
    let key = mapName.toLowerCase()
        .replaceAll(/\W/g, '')
        .replaceAll(/ /g, '')
        .trim()
        .toLowerCase()
    mapNameToUrlObj[key] = URL
})
// console.log(mapNameToUrlObj)

const idMapNameArr = Object.entries(data_map)   // [id, str]
    .map(([id, { streetName, mapName }]) => {
        if (['Aqua Road'].some(s => streetName === s)) {
            if (mapName) mapName = mapName.replace(" : ", ": ")  //  Aqua Road: Forked Road : West Sea
        } else if (['Leafre'].some(s => streetName === s)) {
            if (mapName) mapName = mapName.replace(" : ", " : ")  //  Aqua Road: Forked Road : West Sea
        } else if (['Time Lane', "Memory Keeper"].some(s => streetName === s)) {
            if (mapName) mapName = mapName.replace(/ ([0-9]+)$/, "$1")
            // console.log(mapName)
        }

        let str = decode(`${streetName}: ${mapName}`)
            .replace("<", " <")
            .replace('  ', ' ')
            .trim()

        if (streetName == mapName) {  // amoria
            str = decode(streetName)
                .replace('  ', ' ')
                .trim()
        }

        let key = str.replaceAll(/\W/g, '')
            .replaceAll(/ /g, '')
            .trim()
            .toLowerCase()

        // return [id, str.toLowerCase()]
        return [id, key]
    })

// console.log(idMapNameArr)

let seenNameWithNoMatch = {}

let result = {}
idMapNameArr.forEach(([id, mapName]) => {
    if (mapName in mapNameToUrlObj) {
        result[id] = [mapNameToUrlObj[mapName], true]
    } else {
        // mapName not found
        if (mapName in seenNameWithNoMatch) return
        seenNameWithNoMatch[mapName] = id
        // console.log(mapName)
    }
})


const combine = () => {
    let remove_no_match_from_seenName = true    // toggle switch

    data_mapId_hsUrl_Manual.forEach(({ map_id, bbb_url }) => {
        result[map_id] = [bbb_url, true]
        if (remove_no_match_from_seenName) {
            let key = Object.keys(seenNameWithNoMatch).find(k => seenNameWithNoMatch[k] === map_id)
            delete seenNameWithNoMatch[key]
        }

    })
    //  remove for unmatch
}

// comebine manual data from data_map_Id_hsUrl_Manual.json
combine()

// --- Match Result annoucement  ---
console.log("hidden street map count : ", data_hsMap.length)
console.log(".wz map count : ", idMapNameArr.length)
console.log('.......')
console.log("success matched from mapId to Url : ", Object.keys(result).length - data_mapId_hsUrl_Manual.length)
console.log("manual input url count : ", data_mapId_hsUrl_Manual.length)
console.log("total record mapId - url : ", Object.keys(result).length)
console.log("failed matched name count: ", Object.keys(seenNameWithNoMatch).length)
// console.log(result)
// --- Match Result annoucement  ---


// Write file after ensuring all asynchronous tasks are done
async function writeData() {

    console.log("Start writing into data_MapUrl.json");
    try {
        await fs.writeFile('data_MapUrl.json', JSON.stringify(result, null, 2));
        console.log("Done writing into data_MapUrl.json");
    } catch (error) {
        console.error('Failed to write file:', error);
    }
    // 
    console.log("Start writing not matched name into investigate_mapName.json");
    try {
        await fs.writeFile('investigate_mapName.json', JSON.stringify(seenNameWithNoMatch, null, 2));
        console.log("Done writing into investigate_mapName.json");
    } catch (error) {
        console.error('Failed to write file:', error);
    }
}
writeData()


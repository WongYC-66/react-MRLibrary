import results from './crawl_HS_URL.json'  assert { type: 'json' };
import crawl_HS_LKC_URL from './crawl_HS_LKC_URL.json'  assert { type: 'json' };
import { promises as fs } from 'fs';
console.log(results)

const data = Object.values(crawl_HS_LKC_URL)

try {
    await fs.writeFile('a.json', JSON.stringify(data, null, 2));
    console.log("Done writing into a.json");
} catch (error) {
    console.error('Failed to write file:', error);
}
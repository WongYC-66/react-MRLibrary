import axios from 'axios';
import { promises as fs } from 'fs';
import pLimit from 'p-limit';
import { decode } from 'html-entities';
import * as cheerio from 'cheerio';
// 
import data_map from './data_Map.json' assert { type: 'json' };
// import results from './results.json'  assert { type: 'json' };

let mapArr = Object.entries(data_map)
    .map(([id, obj]) => [id, (obj.streetName + " " + obj.mapName).toLowerCase()])

// console.log(mapArr)
console.log("Total Possible hidden street map Urls = ", mapArr.length)

let urlToMapId = {}
for (let [id, mapStr] of mapArr) {
    let subUrl = decode(mapStr)
        .replaceAll(/[\<\>\-\'\,\.\:]/g, '')
        .replaceAll('  ', '')
        .split(' ')
        .join('-')

    // `https://bbb.hidden-street.net/map/mini-map/ludibrium-forgotten-path-of-time-1`
    let fullURL = `https://bbb.hidden-street.net/map/mini-map/${subUrl}`
    if (!(fullURL in urlToMapId)) urlToMapId[fullURL] = []
    urlToMapId[fullURL].push(id)
}

// console.log(urlToMapId)

var urls = Object.keys(urlToMapId).sort()
// console.log(urls)

// urls = [
//     'https://bbb.hidden-street.net/map/mini-map/time-lane-memory-lane2',
//     , 'https://bbb.hidden-street.net/map/mini-map/time-lane-memory-lane-2'
//     // Add more URLs here
// ];

console.log("unique urls length = ", urls.length)

const urlStatus = {}

async function checkUrl(url) {
    let result = false;
    try {
        const response = await axios.get(url);
        if (response.status === 200) {
            result = true;
            console.log(`URL is working: ${url}`);
        } else {
            console.log(`URL is not working: ${url} (Status: ${response.status})`);
        }
    } catch (error) {
        console.log(`URL is not working: ${url} (Error: ${error.message})`);
    }
    urlStatus[url] = result;
}

// Limit the number of concurrent requests
const limit = pLimit(250); // Adjust concurrency level as needed

async function checkUrls(urls) {
    const promises = urls.map((url) => limit(() => checkUrl(url)));
    await Promise.all(promises);
    console.log('writing');
    await fs.writeFile('urlResults.json', JSON.stringify(urlStatus, null, 2));
    console.log('done writing');
}

function whatAreAllMyUniqueLinks() {
    console.log(urls)
    console.log("start writing into all_my_unique_links.json")
    fs.writeFile('all_my_unique_links.json', JSON.stringify(urls, null, 2)).then(e => {
        console.log("done writing into all_my_unique_links.json")
    });
}


function checkHowManyWorking() {
    let Obj = results
    // {url : true/false}
    let arr = Object.entries(Obj)
    let successUrl = arr.filter(([url, isTrue]) => isTrue)
    console.log(`total unique url : ${arr.length}`)
    console.log(`capture true url : ${successUrl.length}`)

    // 
    let mapIdToUrlRes = {}
    // {id : [url, true]}
    successUrl.forEach(([url, isTrue]) => {
        let mapIds = urlToMapId[url]
        mapIds.forEach(id => mapIdToUrlRes[id] = [url, isTrue])
    })
    // console.log(mapIdToUrlRes)
    let mapIdWithSuccesUrl = Object.keys(mapIdToUrlRes)
    console.log(`after populated, ${mapIdWithSuccesUrl.length} mapId now have url`)
    console.log("start writing into data_MapUrl.json")
    fs.writeFile('data_MapUrl.json', JSON.stringify(mapIdToUrlRes, null, 2)).then(e => {
        console.log("done writing into data_MapUrl.json")
    });
}


function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function crawlMapUrl() {
    
    async function fetchHtml(url) {
        try {
            let response = await axios.get(url);
            return cheerio.load(response.data);
        } catch (error) {
            console.error(`Failed to fetch ${url}: ${error.message}`);
            return cheerio.load(''); // Return empty Cheerio object in case of failure
        }
    }
    
    async function extractLinks(url, selector) {
        let $ = await fetchHtml(url);
        let $a = $(selector);
        let urlArr = $a.map((i, el) => {
            return {
                href: $(el).attr('href'),
                name: $(el).text().trim() // Get the text content and trim any surrounding whitespace
            }
        }).get()
        return urlArr;
    }
    
    async function crawlMapSection() {
        // const baseUrl = 'https://bbb.hidden-street.net/database/';
        const baseUrl = 'https://www.hidden-street.net/gms/worldmap/lion-castle';   // LHC

        // const mapLinks = await extractLinks(baseUrl, `#sidebar-left a[href^='/map']`);
        const mapLinks = await extractLinks(baseUrl, `#block-system-main a[href^='/gms/map']`);   // LHC
        console.log('Extracted mapLinks:', mapLinks);
        
        // return

        // const subBaseUrl = 'https://bbb.hidden-street.net';
        const subBaseUrl = 'https://www.hidden-street.net';
        const results = {};  // 'url' : name
        // const limit = pLimit(15); // Adjust the concurrency level as needed

        const recursiveCrawl = async (linkArr, depth = 0) => {

            if(depth >= 1) return 

            let workload = linkArr.map(async ({ href }) => {
                console.log('Crawling:', subBaseUrl + href);

                let subLinks =  await extractLinks(subBaseUrl + href, `#content a[href^='/map']`)

                subLinks = subLinks
                    .filter(({ href }) => !(href in results))
                    .filter(({ href }) => !href.includes('#'));
                subLinks.forEach(({ href, name }) => results[href] = name);
                // console.log(subLinks)

                console.log("current results size : ", Object.keys(results).length)

                if (subLinks.length > 0) {
                    // await recursiveCrawl(subLinks);
                    await recursiveCrawl(subLinks, depth + 1);
                }
            })

            await Promise.all(workload);
        };

        // await recursiveCrawl(mapLinks);

        mapLinks.forEach(({href, name}) => {
            results[href] = name
        })

        // Write file after ensuring all asynchronous tasks are done
        let fileName = 'crawl_HS_LKC_URL'
        console.log(`Start writing into ${fileName}`);
        try {
            await fs.writeFile(`${fileName}.json`, JSON.stringify(results, null, 2));
            console.log(`Done writing into ${fileName}`);
        } catch (error) {
            console.error('Failed to write file:', error);
        }
    }

    crawlMapSection().catch(error => {
        console.error('Error during crawling:', error);
    });
}


// checkUrls(urls); -- obsolete
// checkHowManyWorking()
// whatAreAllMyUniqueLinks()
crawlMapUrl()  // this better
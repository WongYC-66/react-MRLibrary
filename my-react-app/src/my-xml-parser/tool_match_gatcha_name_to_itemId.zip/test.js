`
Function : For Gacha Item list, it will ignore the original itemID,
and find the new itemID based on the name match with database

HOW TO USE:
1. Copy in the latest files of :
  - data_Eqp.json
  - data_Consume.json
  - data_Ins.json
  - data_Etc.json
  - data_Gacha.json
2. Run in command : node test.js
3. Output is result.json, copy the json, and use it as new data_Gacha.json

PS: use online JSON to excel tool, to help analyse how many missing.

PS: known itemID list having issue to match:
    - 5 million mesos
    - Grey Seal Cushion             -not found
    - Maple Leaf - STR              - only have duplicate name of Maple Leaf
    - Maple Leaf - DEX
    - Maple Leaf - INT
    - Maple Leaf - LUK
    - Pink Flower Tube (Staff)      - name duplicate with another equip
    - White Mouse Kit [3]           - not found
    - Maple Leaf - STR
    - Maple Leaf - DEX
    - Maple Leaf - INT
    - Maple Leaf - LUK
`


import fs from 'fs';
import data_Eqp from './data_Eqp.json'  with { type: 'json' }
import data_Consume from './data_Consume.json'  with { type: 'json' }
import data_Ins from './data_Ins.json'  with { type: 'json' }
import data_Etc from './data_Etc.json'  with { type: 'json' }
import data_Gacha from './data_Gacha.json'  with { type: 'json' }

// ---------------------------------------------------
let libraryMap = {
    ...data_Eqp
}

let others = { ...data_Consume, ...data_Ins, ...data_Etc }
for (let id in others) {
    libraryMap[id] = others[id].name
}
console.log("id to name, count : ", Object.keys(libraryMap).length)

// ---------------------------------------------------
// reverseMap with name:id
let nameToIdMap = {}
for (let [id, name] of Object.entries(libraryMap)) {
    name = name.replaceAll(/\W/g, '')
        .replaceAll(/ /g, '')
        .replaceAll(/[\'\"]/g, '')
        .toLowerCase()
    if (name in nameToIdMap) continue
    nameToIdMap[name] = id
}
console.log("name to id, count : ", Object.keys(nameToIdMap).length)

// ---------------------------------------------------
// console.log(data_Gacha)

const matchAndWrite = () => {
    data_Gacha.forEach(obj => {
        let itemName = obj.name
            .replace('Dark Scroll for Gun for ATT', 'Dark Scroll for Gun for Attack')
            .replace('Scroll for Gun for ATT 60%', 'Scroll for Gun for Attack 60%')
            .replace('Scroll for Knuckler for ATT 60%', 'Scroll for Knuckler for Attack 60%')
            .replace('Dark Scroll for Knuckler for ATT', 'Dark Scroll for Knuckle for Attack')
            .replace('Dark Scroll for Knuckler for Accuracy', 'Dark Scroll for Knuckle for Accuracy')
            .replace(/(Dark )?Scroll for Overall Armor for STR/, 'Scroll for Overall for STR')
            .replace('Black Royale Barone', 'Black Royal Barone')
            .replace('Dark Scroll for Earring for LUK 70%', 'Scroll for Earring for LUK 70%')
            .replace('Gold Hilden Boots', 'Gold Hildon Boots')
            .replace('Gold Hilden Boots', 'Gold Hildon Boots')
            .replace('The Energizer Drink (1~4)', 'The Energizer Drink')
            
            .replaceAll(/\(F\)/g, '')
            .replaceAll(/\(M\)/g, '')
            .replaceAll(/\W/g, '')
            .replaceAll(/ /g, '')
            .toLowerCase()
        obj.itemId = nameToIdMap[itemName]
    })
    let jsonData = JSON.stringify(data_Gacha, null, 2);
    // console.log(jsonData)
    fs.writeFile('result.json', jsonData, (err) => {
        if (err) {
            console.error('Error writing to file : result.json', err);
        } else {
            console.log('Data successfully written to file : result.json');
        }
    });
}


matchAndWrite()